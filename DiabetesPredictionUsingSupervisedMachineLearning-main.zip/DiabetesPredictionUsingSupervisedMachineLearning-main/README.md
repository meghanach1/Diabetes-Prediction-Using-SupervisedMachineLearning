# DiabetesPredictionUsingSupervisedMachineLearning
As a part of our academics, we've done research on diabates which is a major problem across the globe these days.
We all know technology helps to overcome various challenges. So, we've used different supervised machine learning models to predict diabetes over PIMA diabetes.
#Team members
1. Bhargavi Chukkapalli (700743393) 
2. Meghana Chodagiri (700749050) 
3. Kallepu Tejaswi Reddy (700743859) 
4. Deeksha Ceeti (700743669)


Thanks to our professor: Muhammad Zubair Khan University of Missouri - Warrensburg, Missouri. Department of Computer Science and Electrical Engineering, Doctor of Philosophy
